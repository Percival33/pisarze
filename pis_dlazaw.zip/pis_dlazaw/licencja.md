Zrodla, z ktorych uzyskano pliki:
Mickiewicz.txt i Sienkiewicz.txt - wolne lektury
Prus.txt - literat.ug.edu.pl
